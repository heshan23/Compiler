package pass.Analysis;

import IR.IRModule;
import IR.values.BasicBlock;
import IR.values.Function;

import java.util.ArrayList;
import java.util.HashSet;

public class DomAnalysis {
    private static final DomAnalysis domAnalysis = new DomAnalysis();

    public static DomAnalysis getInstance() {
        return domAnalysis;
    }

    public void analyze(IRModule irModule) {
        for (Function function : irModule.getFunctions()) {
            BasicBlock start = function.getBasicBlocks().get(0);
            calcDom(start);
            calcIdom(function.getBasicBlocks());
            calcDF(start);
        }
    }

    private void calcDom(BasicBlock start) {
        while (update(start)) {
            for (BasicBlock basicBlock : start.getNext()) {
                calcDom(basicBlock);
            }
        }
    }

    private boolean update(BasicBlock it) {
        int len = it.getDom().size();
        HashSet<BasicBlock> set = new HashSet<>();
        boolean first = true;
        for (BasicBlock basicBlock : it.getPrev()) {
            if (first) {
                first = false;
                set.addAll(basicBlock.getDom());
            } else {
                set.retainAll(basicBlock.getDom());
            }
        }
        set.add(it);
        it.setDom(set);
        return set.size() != len;
    }

    private boolean dom(BasicBlock a, BasicBlock b) {
        return b.getDom().contains(a);
    }

    private boolean strictDom(BasicBlock a, BasicBlock b) {
        return a != b && dom(a, b);
    }

    private void calcIdom(BasicBlock it) {
        for (BasicBlock basicBlock1 : it.getDom()) {
            if (basicBlock1 == it) {//确保严格支配
                continue;
            }
            boolean flot = true;
            for (BasicBlock basicBlock2 : it.getDom()) {
                if (basicBlock2 == it) {
                    continue;
                }
                if (strictDom(basicBlock1, basicBlock2)) {
                    flot = false;
                    break;
                }
            }
            if (flot) {
                it.setIdom(basicBlock1);
                break;
            }
        }
    }

    private void calcIdom(ArrayList<BasicBlock> basicBlocks) {
        for (BasicBlock basicBlock : basicBlocks) {
            calcIdom(basicBlock);
        }
    }

    private void calcDF(BasicBlock start) {
        for (BasicBlock basicBlock : start.getNext()) {
            BasicBlock x = start;
            while (!strictDom(x, basicBlock)) {
                x.add2DF(basicBlock);
                x = x.getIdom();
            }
            calcDF(basicBlock);
        }
    }
}
