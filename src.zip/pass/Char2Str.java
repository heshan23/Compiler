package pass;

public class Char2Str {
}
