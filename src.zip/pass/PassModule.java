package pass;

import IR.IRModule;
import IR.values.Function;

public class PassModule {
    private static final PassModule passModule = new PassModule();

    public static PassModule getInstance() {
        return passModule;
    }

    public void run(IRModule irModule) {
        new Mem2Reg(irModule).run();

        irModule.refreshName();
    }
}
