package pass;

import IR.IRModule;
import IR.values.BasicBlock;
import IR.values.Function;
import IR.values.instructions.CallInst;
import IR.values.instructions.Instruction;

import java.util.Iterator;

public class DelDeadCode {
    private IRModule irModule;

    public DelDeadCode(IRModule irModule) {
        this.irModule = irModule;
    }

    public void run() {
        while (true) {
            if (!delUnusedCode()) {
                break;
            }
        }
    }

    private void delUnusedFunc() {

    }

    private boolean delUnusedCode() {
        boolean res = false;
        for (Function function : irModule.getFunctions()) {
            for (BasicBlock bb : function.getBasicBlocks()) {
                Iterator<Instruction> it = bb.getInstructions().iterator();
                while (it.hasNext()) {
                    Instruction instr = it.next();
                    if (instr.getName().isEmpty() || instr instanceof CallInst) {
                        continue;
                    }
                    if (instr.unUsed()) {
                        res = true;
                        instr.deleteUse();
                        it.remove();
                    }
                }
            }
        }
        return res;
    }
}
