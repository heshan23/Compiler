package error.symbol;

public enum Type {
    VOID,
    INT,
}
