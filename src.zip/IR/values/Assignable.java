package IR.values;

public interface Assignable {
}
