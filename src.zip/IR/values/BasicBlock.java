package IR.values;

import IO.OutputHandler;
import IR.types.LabelType;
import IR.types.Type;
import IR.values.instructions.BinaryInst;
import IR.values.instructions.Instruction;

import java.util.ArrayList;

public class BasicBlock extends Value {
    private ArrayList<Instruction> instructions;

    public BasicBlock(Function function) {
        super(String.valueOf(valNumber++), new LabelType());
        this.instructions = new ArrayList<>();
        function.addBasicBlock(this);
    }

    public BasicBlock() {
        super("", null);
        this.instructions = new ArrayList<>();
    }

    public void refill(Function function) {
        setName(String.valueOf(valNumber++));
        setType(new LabelType());
        function.addBasicBlock(this);
    }

    public void addInstruction(Instruction instruction) {
        instructions.add(instruction);
    }

    public void genLLVM() {
        OutputHandler.genLLVM(getName() + ":");
        for (Instruction instruction : instructions) {
            OutputHandler.genLLVM("\t" + instruction);
        }
    }
}
