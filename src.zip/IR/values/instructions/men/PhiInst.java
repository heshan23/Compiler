package IR.values.instructions.men;

import IR.types.IntegerType;
import IR.types.Type;
import IR.values.BasicBlock;
import IR.values.Value;
import IR.values.instructions.Instruction;
import IR.values.instructions.Operator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class PhiInst extends MemInst {
    private final HashMap<Value, BasicBlock> map = new HashMap<>();

    public PhiInst() {
        super(IntegerType.i32, Operator.Phi);
        setName("%" + valNumber++);
    }

    public void addValue(BasicBlock basicBlock, Value value) {
        map.put(value, basicBlock);
        addOperand(value);
    }

    @Override
    public String toString() {
        StringBuilder ans = new StringBuilder(getName() + " = phi " + getType());
        for (Value value : getOperands()) {
            ans.append(" [ ");
            ans.append(value.getName()).append(", %");
            ans.append(map.get(value).getName());
            ans.append(" ],");
        }
        ans.deleteCharAt(ans.length() - 1);
        return ans.toString();
    }
}
