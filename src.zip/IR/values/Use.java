package IR.values;

public class Use {
    private Value value;
    private User user;
    private int pos;
}
