package IR.types;

public interface Type {
}
