package symbol;

public enum Type {
    VOID,
    INT,
}
